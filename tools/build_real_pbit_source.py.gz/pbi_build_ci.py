import csv, json, base64, zlib, shutil, re, uuid, zipfile
from pathlib import Path
from xml.sax.saxutils import escape as xml_escape

ROOT = Path.cwd()
OUT = ROOT/'build'/'walmart_pbit_pbixproj'
THEME_SRC = ROOT/'powerbi'/'theme_ci_base.json'

# ---------------- model spec ----------------
planner_cols = [
('id','string',None,'none'),('item_store_key','string',None,'none'),('item_id','string',None,'none'),('dept_id','string',None,'none'),('cat_id','string',None,'none'),('store_id','string',None,'none'),('state_id','string',None,'none'),
('units_365d','int64','#,##0','sum'),('revenue_365d','double','$#,##0.00;-$#,##0.00','sum'),('active_days_365d','int64','#,##0','sum'),('zero_share_365d','double','0.00','none'),('adi','double','0.00','none'),('cv2_nonzero_demand','double','0.00','none'),('demand_segment','string',None,'none'),('weekly_cv','double','0.00','none'),('abc_class','string',None,'none'),('xyz_class','string',None,'none'),('abc_xyz','string',None,'none'),('preceding_28d_units','int64','#,##0','sum'),('prior_28d_units','int64','#,##0','sum'),('forecast_28d_units','double','#,##0.0','sum'),('forecast_unit_change','double','#,##0.0','sum'),('forecast_growth_pct','double','0.0','none'),('recent_run_rate_change_pct','double','0.0','none'),('avg_daily_forecast','double','0.00','none'),('demand_sigma_90d','double','0.00','none'),('service_level_scenario','string',None,'none'),('lead_time_scenario_days','int64','0','none'),('review_period_scenario_days','int64','0','none'),('safety_stock_scenario_units','double','#,##0.0','sum'),('reorder_point_scenario_units','double','#,##0.0','sum'),('target_stock_scenario_units','double','#,##0.0','sum'),('planning_change_signal_pct','double','0.0','none'),('demand_risk_score','double','0.0','none'),('planner_action','string',None,'none'),('forecast_model_route','string',None,'none'),('forecast_start_date','dateTime','Short Date','none'),('forecast_end_date','dateTime','Short Date','none')]

planner_measures = [
('Forecast Units 28D','SUM ( PlannerActionCenter[forecast_28d_units] )','#,##0'),
('Prior Units 28D','SUM ( PlannerActionCenter[prior_28d_units] )','#,##0'),
('Forecast Unit Change','[Forecast Units 28D] - [Prior Units 28D]','#,##0'),
('Forecast Growth %','DIVIDE ( [Forecast Unit Change], [Prior Units 28D] )','0.0%;-0.0%;0.0%'),
('Revenue 365D','SUM ( PlannerActionCenter[revenue_365d] )','$#,##0;-$#,##0'),
('Units 365D','SUM ( PlannerActionCenter[units_365d] )','#,##0'),
('Item-Store Count','DISTINCTCOUNT ( PlannerActionCenter[item_store_key] )','#,##0'),
('Average Risk Score','AVERAGE ( PlannerActionCenter[demand_risk_score] )','0.0'),
('High-Risk Item-Store Count','CALCULATE ( [Item-Store Count], KEEPFILTERS ( PlannerActionCenter[demand_risk_score] >= 70 ) )','#,##0'),
('High-Risk Revenue','CALCULATE ( [Revenue 365D], KEEPFILTERS ( PlannerActionCenter[demand_risk_score] >= 70 ) )','$#,##0;-$#,##0'),
('High-Risk Revenue Share','DIVIDE ( [High-Risk Revenue], [Revenue 365D] )','0.0%'),
('A-Class Revenue','CALCULATE ( [Revenue 365D], REMOVEFILTERS ( PlannerActionCenter[abc_class] ), PlannerActionCenter[abc_class] = "A" )','$#,##0;-$#,##0'),
('A-Class Revenue Share','DIVIDE ( [A-Class Revenue], CALCULATE ( [Revenue 365D], REMOVEFILTERS ( PlannerActionCenter[abc_class] ) ) )','0.0%'),
('Growth Review Count','CALCULATE ( [Item-Store Count], KEEPFILTERS ( PlannerActionCenter[planning_change_signal_pct] >= 20 ) )','#,##0'),
('Decline Review Count','CALCULATE ( [Item-Store Count], KEEPFILTERS ( PlannerActionCenter[planning_change_signal_pct] <= -20 ) )','#,##0'),
('Planning Change Signal %','DIVIDE ( AVERAGE ( PlannerActionCenter[planning_change_signal_pct] ), 100 )','0.0%;-0.0%;0.0%'),
('Baseline Safety Stock Units','SUM ( PlannerActionCenter[safety_stock_scenario_units] )','#,##0'),
('Baseline Reorder Point Units','SUM ( PlannerActionCenter[reorder_point_scenario_units] )','#,##0'),
('Baseline Target Stock Units','SUM ( PlannerActionCenter[target_stock_scenario_units] )','#,##0'),
('Scenario Lead Time Days','SELECTEDVALUE ( ScenarioLeadTime[Value], 14 )','0'),
('Scenario Review Period Days','SELECTEDVALUE ( ScenarioReviewPeriod[Days], 7 )','0'),
('Scenario Service Label','SELECTEDVALUE ( ScenarioServiceLevel[Scenario], "ABC default" )',''),
('Scenario Z Override','SELECTEDVALUE ( ScenarioServiceLevel[Z] )','0.000'),
('Scenario Safety Stock Units', '''VAR LeadTime = [Scenario Lead Time Days]\nVAR ScenarioLabel = [Scenario Service Label]\nVAR OverrideZ = [Scenario Z Override]\nRETURN\nSUMX (\n    PlannerActionCenter,\n    VAR ClassZ = SWITCH ( PlannerActionCenter[abc_class], "A", 1.645, "B", 1.282, "C", 1.036, 1.282 )\n    VAR ZValue = IF ( ScenarioLabel = "ABC default", ClassZ, OverrideZ )\n    RETURN ZValue * PlannerActionCenter[demand_sigma_90d] * SQRT ( LeadTime )\n)''','#,##0'),
('Scenario Reorder Point Units', '''VAR LeadTime = [Scenario Lead Time Days]\nVAR ScenarioLabel = [Scenario Service Label]\nVAR OverrideZ = [Scenario Z Override]\nRETURN\nSUMX (\n    PlannerActionCenter,\n    VAR ClassZ = SWITCH ( PlannerActionCenter[abc_class], "A", 1.645, "B", 1.282, "C", 1.036, 1.282 )\n    VAR ZValue = IF ( ScenarioLabel = "ABC default", ClassZ, OverrideZ )\n    VAR Safety = ZValue * PlannerActionCenter[demand_sigma_90d] * SQRT ( LeadTime )\n    RETURN PlannerActionCenter[avg_daily_forecast] * LeadTime + Safety\n)''','#,##0'),
('Scenario Target Stock Units', '''VAR LeadTime = [Scenario Lead Time Days]\nVAR ReviewDays = [Scenario Review Period Days]\nVAR ScenarioLabel = [Scenario Service Label]\nVAR OverrideZ = [Scenario Z Override]\nRETURN\nSUMX (\n    PlannerActionCenter,\n    VAR ClassZ = SWITCH ( PlannerActionCenter[abc_class], "A", 1.645, "B", 1.282, "C", 1.036, 1.282 )\n    VAR ZValue = IF ( ScenarioLabel = "ABC default", ClassZ, OverrideZ )\n    VAR Safety = ZValue * PlannerActionCenter[demand_sigma_90d] * SQRT ( LeadTime )\n    RETURN PlannerActionCenter[avg_daily_forecast] * ( LeadTime + ReviewDays ) + Safety\n)''','#,##0'),
('Scenario Safety Stock Delta','[Scenario Safety Stock Units] - [Baseline Safety Stock Units]','#,##0;[Red]-#,##0'),
('Scenario Target Stock Delta','[Scenario Target Stock Units] - [Baseline Target Stock Units]','#,##0;[Red]-#,##0'),
('Scenario Target Stock Delta %','DIVIDE ( [Scenario Target Stock Delta], [Baseline Target Stock Units] )','0.0%;[Red]-0.0%;0.0%'),
]

forecast_cols=[('id','string',None,'none'),('item_store_key','string',None,'none'),('item_id','string',None,'none'),('dept_id','string',None,'none'),('cat_id','string',None,'none'),('store_id','string',None,'none'),('state_id','string',None,'none'),('forecast_week','int64','0','none'),('week_start_date','dateTime','Short Date','none'),('week_end_date','dateTime','Short Date','none'),('forecast_units','double','#,##0.0','sum')]
forecast_measures=[('Weekly Forecast Units','SUM ( ForecastWeekly[forecast_units] )','#,##0')]
baseline_cols=[('segment','string',None,'none'),('model','string',None,'none'),('avg_wape','double','0.0000','none'),('avg_mae','double','0.0000','none'),('avg_rmse','double','0.0000','none'),('avg_bias_pct','double','0.0000','none')]
baseline_measures=[('Baseline WAPE','AVERAGE ( BaselineModelSummary[avg_wape] )','0.0%'),('Baseline RMSE','AVERAGE ( BaselineModelSummary[avg_rmse] )','0.00'),('Baseline Bias %','AVERAGE ( BaselineModelSummary[avg_bias_pct] )','0.0%;-0.0%;0.0%')]
priority_cols=[('model','string',None,'none'),('wape','double','0.0000','none'),('mae','double','0.0000','none'),('rmse','double','0.0000','none'),('bias_pct','double','0.0000','none')]
priority_measures=[('Model WAPE','MAX ( PriorityModelHoldout[wape] )','0.0%'),('Priority LightGBM WAPE','CALCULATE ( MAX ( PriorityModelHoldout[wape] ), PriorityModelHoldout[model] = "LightGBM" )','0.0%'),('Priority MA28 WAPE','CALCULATE ( MAX ( PriorityModelHoldout[wape] ), PriorityModelHoldout[model] = "MA28" )','0.0%'),('Priority WAPE Improvement %','DIVIDE ( [Priority MA28 WAPE] - [Priority LightGBM WAPE], [Priority MA28 WAPE] )','0.0%'),('Priority LightGBM Bias %','CALCULATE ( MAX ( PriorityModelHoldout[bias_pct] ), PriorityModelHoldout[model] = "LightGBM" )','0.0%;-0.0%;0.0%')]
feature_cols=[('feature','string',None,'none'),('importance_gain','double','#,##0.0','sum'),('share','double','0.0000','sum')]
feature_measures=[('Feature Importance Share','SUM ( FeatureImportance[share] )','0.0%')]
scenario_lt_cols=[('Value','int64','0','none')]
scenario_rp_cols=[('Days','int64','0','none')]
scenario_sl_cols=[('Scenario','string',None,'none'),('Z','double','0.000','none')]

TABLES = {
    'PlannerActionCenter': {'csv': ROOT/'data'/'processed'/'planner_action_center.csv','cols':planner_cols,'measures':planner_measures},
    'ForecastWeekly': {'csv': ROOT/'data'/'processed'/'forecast_weekly_item_store.csv','cols':forecast_cols,'measures':forecast_measures},
    'BaselineModelSummary': {'csv': ROOT/'outputs'/'baseline_model_summary.csv','cols':baseline_cols,'measures':baseline_measures},
    'PriorityModelHoldout': {'csv': ROOT/'outputs'/'priority_model_holdout.csv','cols':priority_cols,'measures':priority_measures},
    'FeatureImportance': {'csv': ROOT/'outputs'/'priority_feature_importance.csv','cols':feature_cols,'measures':feature_measures},
    'ScenarioLeadTime': {'rows': [[i] for i in range(7,29)],'cols':scenario_lt_cols,'measures':[]},
    'ScenarioReviewPeriod': {'rows': [[0],[7],[14],[21],[28]],'cols':scenario_rp_cols,'measures':[]},
    'ScenarioServiceLevel': {'rows': [['ABC default',None],['85%',1.036],['90%',1.282],['95%',1.645],['97%',1.881],['99%',2.326]],'cols':scenario_sl_cols,'measures':[]},
}

RELATIONSHIPS=[('rel-weekly-planner','ForecastWeekly','item_store_key','PlannerActionCenter','item_store_key',True)]
M_TYPES={'int64':'Int64.Type','string':'Text.Type','double':'Double.Type','dateTime':'Date.Type','boolean':'Logical.Type','decimal':'Currency.Type'}

# ---------- io ----------
def jwrite(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

def safe_file_name(s): return re.sub(r'[<>:"/\\|?*]','_',s)

def read_rows(spec):
    names=[c[0] for c in spec['cols']]
    if 'rows' in spec: return spec['rows']
    rows=[]
    with open(spec['csv'],newline='',encoding='utf-8-sig') as f:
        r=csv.DictReader(f)
        for row in r:
            rows.append([None if row.get(n) in (None,'') else row.get(n) for n in names])
    return rows

def build_embedded_m(spec):
    cols=spec['cols']; names=[c[0] for c in cols]; rows=read_rows(spec)
    raw=json.dumps(rows,separators=(',',':'),ensure_ascii=False).encode('utf-8')
    comp=zlib.compress(raw,9)[2:-4]
    b64=base64.b64encode(comp).decode('ascii')
    chunks=[b64[i:i+60000] for i in range(0,len(b64),60000)]
    # Build a typed nullable text table then apply types.
    fields=', '.join(f'#"{n.replace(chr(34),chr(34)*2)}" = type nullable text' for n in names)
    transforms=[]
    for n,t,_,_ in cols:
        transforms.append('{"%s", %s}'%(n.replace('"','""'),M_TYPES[t]))
    ch=',\n            '.join('"'+c+'"' for c in chunks)
    return ('let\n'
            '    Encoded = Text.Combine({\n            '+ch+'\n        }),\n'
            '    Raw = Json.Document(Binary.Decompress(Binary.FromText(Encoded, BinaryEncoding.Base64), Compression.Deflate)),\n'
            f'    Source = Table.FromRows(Raw, type table [{fields}]),\n'
            f'    #"Changed Type" = Table.TransformColumnTypes(Source, {{{", ".join(transforms)}}})\n'
            'in\n    #"Changed Type"\n')

# ---------- model ----------
def write_model(out):
    jwrite(out/'Model'/'database.json',{
        'name':'Walmart_M5_Demand_Planning','compatibilityLevel':1550,
        'model':{'culture':'en-US','dataAccessOptions':{'legacyRedirects':True,'returnErrorValuesAsNull':True},
                 'defaultPowerBIDataSourceVersion':'powerBI_V3','sourceQueryCulture':'en-US',
                 'relationships':[{'name':n,'fromTable':ft,'fromColumn':fc,'toTable':tt,'toColumn':tc,**({} if active else {'isActive':False})} for n,ft,fc,tt,tc,active in RELATIONSHIPS],
                 'annotations':[{'name':'__PBI_TimeIntelligenceEnabled','value':'0'},
                                {'name':'PBIDesktopVersion','value':'2.155.0000.0 (26.06)'},
                                {'name':'PBI_QueryOrder','value':json.dumps(list(TABLES),separators=(',',':'))}]}
    })
    for tname,spec in TABLES.items():
        tdir=out/'Model'/'tables'/tname
        jwrite(tdir/'table.json',{'name':tname})
        for cname,dtype,fmt,summ in spec['cols']:
            col={'name':cname,'dataType':dtype,'sourceColumn':cname,'summarizeBy':summ,
                 'annotations':[{'name':'SummarizationSetBy','value':'User'}]}
            if fmt: col['formatString']=fmt
            jwrite(tdir/'columns'/f'{safe_file_name(cname)}.json',col)
        for mname,dax,fmt in spec['measures']:
            mdir=tdir/'measures'; mdir.mkdir(parents=True,exist_ok=True)
            fn=safe_file_name(mname)
            (mdir/f'{fn}.dax').write_text(dax+'\n',encoding='utf-8')
            fmt_xml=xml_escape(fmt or '')
            (mdir/f'{fn}.xml').write_text(f'<Measure Name="{xml_escape(mname)}">\n  <FormatString>{fmt_xml}</FormatString>\n</Measure>',encoding='utf-8')
        qdir=out/'Model'/'queries'; qdir.mkdir(parents=True,exist_ok=True)
        (qdir/f'{tname}.m').write_text(build_embedded_m(spec),encoding='utf-8')

# ---------- visual helpers ----------
def ent(alias): return {'SourceRef':{'Source':alias}}
def msel(alias,table,prop): return {'Measure':{'Expression':ent(alias),'Property':prop},'Name':f'{table}.{prop}','NativeReferenceName':prop}
def csel(alias,table,prop): return {'Column':{'Expression':ent(alias),'Property':prop},'Name':f'{table}.{prop}','NativeReferenceName':prop}
def aggsel(alias,table,prop,func=0):
    # func: 0 sum, 1 avg, 3 count? Avoid where possible.
    return {'Aggregation':{'Expression':{'Column':{'Expression':ent(alias),'Property':prop}},'Function':func},'Name':f'{table}.{prop}','NativeReferenceName':prop}
def ref(sel): return sel['Name']

def vc(vtype,pos,froms,selects,projections,order_by=None):
    pq={'Version':2,'From':[{'Name':a,'Entity':e,'Type':0} for a,e in froms],'Select':selects}
    if order_by: pq['OrderBy']=order_by
    return {'name':uuid.uuid4().hex[:20], 'layouts':[{'id':0,'position':pos}],
            'singleVisual':{'visualType':vtype,'projections':projections,'prototypeQuery':pq,'drillFilterOtherVisuals':True}}

def card(x,y,w,h,table,measure,alias='p'):
    s=msel(alias,table,measure); return vc('card',{'x':x,'y':y,'z':0,'width':w,'height':h},[(alias,table)],[s],{'Values':[{'queryRef':ref(s)}]})
def slicer(x,y,w,h,table,col,alias='p'):
    s=csel(alias,table,col); return vc('slicer',{'x':x,'y':y,'z':0,'width':w,'height':h},[(alias,table)],[s],{'Values':[{'queryRef':ref(s)}]})
def bar(x,y,w,h,cat_table,cat_col,measure_table,measures,series=None,vtype='clusteredBarChart'):
    froms=[]; aliases={}
    def alias_for(t):
        if t not in aliases:
            aliases[t]=chr(97+len(aliases)); froms.append((aliases[t],t))
        return aliases[t]
    sels=[]; projs={}
    ca=alias_for(cat_table); cs=csel(ca,cat_table,cat_col); sels.append(cs); projs['Category']=[{'queryRef':ref(cs)}]
    ys=[]
    for m in measures:
        ma=alias_for(measure_table); ms=msel(ma,measure_table,m); sels.append(ms); ys.append({'queryRef':ref(ms)})
    projs['Y']=ys
    if series:
        st,sc=series; sa=alias_for(st); ss=csel(sa,st,sc); sels.append(ss); projs['Series']=[{'queryRef':ref(ss)}]
    ob=[{'Direction':2,'Expression':{'Measure':{'Expression':ent(alias_for(measure_table)),'Property':measures[0]}}}]
    return vc(vtype,{'x':x,'y':y,'z':0,'width':w,'height':h},froms,sels,projs,ob)
def donut(x,y,w,h,cat_table,cat_col,measure_table,measure,vtype='donutChart'):
    ca='a'; ma='b' if measure_table!=cat_table else 'a'; froms=[(ca,cat_table)] + ([] if ma=='a' else [(ma,measure_table)])
    cs=csel(ca,cat_table,cat_col); ms=msel(ma,measure_table,measure)
    return vc(vtype,{'x':x,'y':y,'z':0,'width':w,'height':h},froms,[cs,ms],{'Category':[{'queryRef':ref(cs)}],'Y':[{'queryRef':ref(ms)}]})
def line(x,y,w,h,cat_table,cat_col,measure_table,measure): return bar(x,y,w,h,cat_table,cat_col,measure_table,[measure],vtype='lineChart')
def tablev(x,y,w,h,fields,sort_measure=None):
    aliases={}; froms=[]; sels=[]; vals=[]
    def alias_for(t):
        if t not in aliases:
            aliases[t]=chr(97+len(aliases)); froms.append((aliases[t],t))
        return aliases[t]
    for kind,t,n in fields:
        a=alias_for(t); s=msel(a,t,n) if kind=='m' else csel(a,t,n); sels.append(s); vals.append({'queryRef':ref(s)})
    ob=None
    if sort_measure:
        t,m=sort_measure; a=alias_for(t); ob=[{'Direction':2,'Expression':{'Measure':{'Expression':ent(a),'Property':m}}}]
    return vc('tableEx',{'x':x,'y':y,'z':0,'width':w,'height':h},froms,sels,{'Values':vals},ob)

# ---------- pages ----------
def page1():
    V=[]
    # 6 compact slicers
    sx=[20,225,430,635,840,1045]
    specs=[('state_id'),('store_id'),('cat_id'),('dept_id'),('abc_class'),('demand_segment')]
    for x,c in zip(sx,specs): V.append(('slicer',slicer(x,15,190,55,'PlannerActionCenter',c)))
    cardspec=[('Forecast Units 28D'),('Prior Units 28D'),('Forecast Growth %'),('A-Class Revenue Share'),('High-Risk Item-Store Count'),('Priority LightGBM WAPE')]
    for i,m in enumerate(cardspec):
        t='PriorityModelHoldout' if m=='Priority LightGBM WAPE' else 'PlannerActionCenter'
        V.append(('card',card(20+i*205,80,190,90,t,m,'r' if t!='PlannerActionCenter' else 'p')))
    V += [
      ('bar',bar(20,185,590,210,'PlannerActionCenter','dept_id','PlannerActionCenter',['Forecast Units 28D','Prior Units 28D'],vtype='clusteredColumnChart')),
      ('bar',bar(630,185,310,210,'PlannerActionCenter','state_id','PlannerActionCenter',['Forecast Units 28D'])),
      ('donut',donut(960,185,300,210,'PlannerActionCenter','demand_segment','PlannerActionCenter','Item-Store Count')),
      ('matrix',tablev(20,410,440,280,[('c','PlannerActionCenter','abc_class'),('c','PlannerActionCenter','xyz_class'),('m','PlannerActionCenter','Revenue 365D'),('m','PlannerActionCenter','Item-Store Count')],('PlannerActionCenter','Revenue 365D'))),
      ('table',tablev(480,410,780,280,[('c','PlannerActionCenter','item_id'),('c','PlannerActionCenter','store_id'),('c','PlannerActionCenter','dept_id'),('c','PlannerActionCenter','abc_xyz'),('c','PlannerActionCenter','demand_segment'),('c','PlannerActionCenter','planner_action'),('c','PlannerActionCenter','forecast_model_route'),('c','PlannerActionCenter','demand_risk_score'),('c','PlannerActionCenter','planning_change_signal_pct')]))
    ]
    return V

def page2():
    V=[]
    for x,c in zip([20,280,540],['item_id','store_id','demand_segment']): V.append(('slicer',slicer(x,15,240,60,'PlannerActionCenter',c)))
    for i,m in enumerate(['Priority LightGBM WAPE','Priority WAPE Improvement %','Priority LightGBM Bias %']): V.append(('card',card(820+i*145,15,135,100,'PriorityModelHoldout',m,'q')))
    V += [
      ('bar',bar(20,135,380,240,'PriorityModelHoldout','model','PriorityModelHoldout',['Model WAPE'],vtype='clusteredColumnChart')),
      ('bar',bar(420,135,410,240,'BaselineModelSummary','segment','BaselineModelSummary',['Baseline WAPE'],series=('BaselineModelSummary','model'),vtype='clusteredColumnChart')),
      ('bar',bar(850,135,410,240,'FeatureImportance','feature','FeatureImportance',['Feature Importance Share'])),
      ('line',line(20,395,1240,295,'ForecastWeekly','week_start_date','ForecastWeekly','Weekly Forecast Units')),
    ]
    return V

def page3():
    V=[]
    for x,c in zip([20,225,430,635,840],['cat_id','dept_id','store_id','abc_class','xyz_class']): V.append(('slicer',slicer(x,15,190,55,'PlannerActionCenter',c)))
    for i,m in enumerate(['Revenue 365D','Units 365D','Item-Store Count','Growth Review Count','Decline Review Count']): V.append(('card',card(20+i*245,80,230,90,'PlannerActionCenter',m)))
    V += [
      ('bar',bar(20,185,430,220,'PlannerActionCenter','dept_id','PlannerActionCenter',['Revenue 365D'])),
      ('donut',donut(470,185,300,220,'PlannerActionCenter','abc_class','PlannerActionCenter','Revenue 365D')),
      ('donut',donut(790,185,300,220,'PlannerActionCenter','xyz_class','PlannerActionCenter','Item-Store Count')),
      ('bar',bar(1110,185,150,220,'PlannerActionCenter','cat_id','PlannerActionCenter',['Forecast Units 28D'])),
      ('table',tablev(20,425,1240,265,[('c','PlannerActionCenter','item_id'),('c','PlannerActionCenter','store_id'),('c','PlannerActionCenter','dept_id'),('c','PlannerActionCenter','abc_class'),('c','PlannerActionCenter','xyz_class'),('c','PlannerActionCenter','revenue_365d'),('c','PlannerActionCenter','units_365d'),('c','PlannerActionCenter','forecast_28d_units'),('c','PlannerActionCenter','planning_change_signal_pct'),('c','PlannerActionCenter','demand_risk_score')]))
    ]
    return V

def page4():
    V=[]
    for x,c in zip([20,225,430,635,840],['planner_action','abc_class','demand_segment','forecast_model_route','store_id']): V.append(('slicer',slicer(x,15,190,55,'PlannerActionCenter',c)))
    for i,m in enumerate(['High-Risk Item-Store Count','High-Risk Revenue Share','Growth Review Count','Decline Review Count','Average Risk Score']): V.append(('card',card(20+i*245,80,230,90,'PlannerActionCenter',m)))
    V.append(('table',tablev(20,190,1240,500,[('c','PlannerActionCenter','item_id'),('c','PlannerActionCenter','store_id'),('c','PlannerActionCenter','dept_id'),('c','PlannerActionCenter','abc_xyz'),('c','PlannerActionCenter','demand_segment'),('c','PlannerActionCenter','prior_28d_units'),('c','PlannerActionCenter','forecast_28d_units'),('c','PlannerActionCenter','forecast_growth_pct'),('c','PlannerActionCenter','planning_change_signal_pct'),('c','PlannerActionCenter','demand_risk_score'),('c','PlannerActionCenter','safety_stock_scenario_units'),('c','PlannerActionCenter','reorder_point_scenario_units'),('c','PlannerActionCenter','forecast_model_route'),('c','PlannerActionCenter','planner_action')])))
    return V

def page5():
    V=[]
    V += [('slicer',slicer(20,15,250,65,'ScenarioLeadTime','Value','l')),
          ('slicer',slicer(290,15,250,65,'ScenarioReviewPeriod','Days','r')),
          ('slicer',slicer(560,15,300,65,'ScenarioServiceLevel','Scenario','s')),
          ('slicer',slicer(880,15,180,65,'PlannerActionCenter','abc_class','p')),
          ('slicer',slicer(1080,15,180,65,'PlannerActionCenter','dept_id','p'))]
    ms=['Baseline Safety Stock Units','Scenario Safety Stock Units','Scenario Safety Stock Delta','Scenario Reorder Point Units','Scenario Target Stock Units','Scenario Target Stock Delta %']
    for i,m in enumerate(ms): V.append(('card',card(20+i*205,95,190,95,'PlannerActionCenter',m)))
    V += [
      ('bar',bar(20,210,590,230,'PlannerActionCenter','abc_class','PlannerActionCenter',['Baseline Target Stock Units','Scenario Target Stock Units'],vtype='clusteredColumnChart')),
      ('bar',bar(630,210,630,230,'PlannerActionCenter','dept_id','PlannerActionCenter',['Scenario Target Stock Units'])),
      ('table',tablev(20,460,1240,230,[('c','PlannerActionCenter','dept_id'),('c','PlannerActionCenter','abc_class'),('c','PlannerActionCenter','service_level_scenario'),('m','PlannerActionCenter','Baseline Safety Stock Units'),('m','PlannerActionCenter','Scenario Safety Stock Units'),('m','PlannerActionCenter','Scenario Reorder Point Units'),('m','PlannerActionCenter','Baseline Target Stock Units'),('m','PlannerActionCenter','Scenario Target Stock Units'),('m','PlannerActionCenter','Scenario Target Stock Delta')]))
    ]
    return V

PAGES=[('Executive Planning Overview',page1()),('Demand Forecast & Model Performance',page2()),('Merchandise & Assortment Planning',page3()),('Planner Action Center',page4()),('Scenario Planning',page5())]

# ---------- report/root ----------
def write_root(out):
    jwrite(out/'.pbixproj.json',{'version':'1.0','settings':{'model':{'serializationMode':'Default'}}})
    (out/'Version.txt').write_text('1.25',encoding='utf-8')
    jwrite(out/'ReportMetadata.json',{'Version':5,'AutoCreatedRelationships':[],'FileDescription':'','CreatedFrom':'Cloud','CreatedFromRelease':'2021.11'})
    jwrite(out/'ReportSettings.json',{'Version':1,'ReportSettings':{},'QueriesSettings':{'TypeDetectionEnabled':True,'RelationshipImportEnabled':True,'RunBackgroundAnalysis':True,'Version':'2.81.5831.821'}})
    nodes=[]
    for i,t in enumerate(TABLES):
        nodes.append({'location':{'x':40+(i%4)*280,'y':40+(i//4)*240},'nodeIndex':t,'size':{'height':200,'width':230},'zIndex':i+1})
    jwrite(out/'DiagramLayout.json',{'version':'1.1.0','diagrams':[{'ordinal':0,'scrollPosition':{'x':0,'y':0},'nodes':nodes,'name':'All tables','zoomValue':100,'pinKeyFieldsToTop':False,'showExtraHeaderInfo':False,'hideKeyFieldsWhenCollapsed':False}],'selectedDiagram':'All tables','defaultDiagram':'All tables'})

def write_report(out):
    theme_name=THEME_SRC.stem
    jwrite(out/'Report'/'report.json',{'id':0,'layoutOptimization':0,'resourcePackages':[{'resourcePackage':{'disabled':False,'name':'SharedResources','type':2,'items':[{'name':theme_name,'path':f'BaseThemes/{THEME_SRC.name}','type':202}]}}]})
    jwrite(out/'Report'/'config.json',{'version':'5.9','themeCollection':{'baseTheme':{'name':theme_name,'version':'5.10','type':2}},'activeSectionIndex':0,'defaultDrillFilterOtherVisuals':True,'settings':{'useNewFilterPaneExperience':True}})
    dst=out/'StaticResources'/'SharedResources'/'BaseThemes'/THEME_SRC.name; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(THEME_SRC,dst)
    for pi,(pname,visuals) in enumerate(PAGES):
        sec=out/'Report'/'sections'/f'{pi:03d}_{safe_file_name(pname)}'
        jwrite(sec/'section.json',{'displayName':pname,'displayOption':1,'height':720,'name':f'ReportSection{pi if pi else ""}','ordinal':pi,'width':1280})
        jwrite(sec/'config.json',{}); jwrite(sec/'filters.json',[])
        for zi,(label,cfg) in enumerate(visuals):
            cfg['layouts'][0]['position']['z']=zi
            vdir=sec/'visualContainers'/f'{zi:05d}_{label}_{cfg["name"][:5]}'
            pos=cfg['layouts'][0]['position']
            jwrite(vdir/'visualContainer.json',{k:pos[k] for k in ('height','width','x','y','z')})
            jwrite(vdir/'config.json',cfg); jwrite(vdir/'filters.json',[])

def qa_source(out):
    files=list(out.rglob('*'))
    missing=[]
    for p in ['.pbixproj.json','Version.txt','ReportMetadata.json','ReportSettings.json','DiagramLayout.json','Model/database.json','Report/report.json','Report/config.json']:
        if not (out/p).exists(): missing.append(p)
    assert not missing,missing
    assert len(list((out/'Report'/'sections').iterdir()))==5
    assert len(list((out/'Model'/'queries').glob('*.m')))==len(TABLES)
    # all visual queryRefs must correspond to selected Names
    bad=[]; vcount=0
    for p in (out/'Report'/'sections').rglob('config.json'):
        if 'visualContainers' not in str(p): continue
        c=json.loads(p.read_text())
        sv=c.get('singleVisual',{}); pq=sv.get('prototypeQuery',{}); names={s.get('Name') for s in pq.get('Select',[])}
        refs=[]
        for role,arr in sv.get('projections',{}).items(): refs += [x.get('queryRef') for x in arr]
        if any(r not in names for r in refs): bad.append((str(p),refs,names))
        vcount += 1
    assert not bad,bad[:3]
    return {'pages':5,'visuals':vcount,'tables':len(TABLES),'queries':len(TABLES)}

def main():
    if not THEME_SRC.exists(): raise FileNotFoundError(THEME_SRC)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    if OUT.exists(): shutil.rmtree(OUT)
    write_root(OUT); write_model(OUT); write_report(OUT)
    qa=qa_source(OUT)
    zipout=ROOT/'build'/'walmart_pbit_pbixproj.zip'
    if zipout.exists(): zipout.unlink()
    with zipfile.ZipFile(zipout,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in OUT.rglob('*'):
            if p.is_file(): z.write(p,p.relative_to(OUT).as_posix())
    qa['zip_bytes']=zipout.stat().st_size
    ROOT/'build'/'walmart_pbit_source_qa.json'.write_text(json.dumps(qa,indent=2),encoding='utf-8')
    print(json.dumps(qa,indent=2)); print(zipout)

if __name__=='__main__': main()
